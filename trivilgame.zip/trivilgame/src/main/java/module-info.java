module com.example.trivilgame {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.trivilgame to javafx.fxml;
    exports com.example.trivilgame;
}