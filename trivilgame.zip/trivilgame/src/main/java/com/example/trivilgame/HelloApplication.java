package com.example.trivilgame;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private int score = 0;
    private int currentQuestionIndex = 0;

    // Sample questions array (replace with your questions)
    private Question[] questions = {
            new Question("Seboko sa Borena ba Basotho ke mang?", new String[]{"Basia", "Bafokeng", "Bakuena", "Bahlakoana"}, 2, "crocodile.jpg"),
            new Question("Basotho ba fumane boipuso ka lemo se fe?", new String[]{"1966", "2008", "1920", "2001"}, 0, "thaba bosiu.jpg"),
            new Question("linku tse tsamaeang le khomo tsa bohali li bitsoa?", new String[]{"Moqhoba", "Setsiba", "Molisana", "Lesaka"}, 1, "likhomo.jpg"),
            new Question("Moo banana ba Basotho ba lulang mmoho?", new String[]{"Khotla", "Selibeng", "Thakaneng", "Nokeng"}, 2, "basotho girls.jpg")
    };

    private Label questionLabel;
    private ToggleGroup optionsToggleGroup;
    private ImageView imageView;
    private Label feedbackLabel;
    private Label scoreLabel;

    @Override
    public void start(Stage primaryStage) {
        questionLabel = new Label();
        optionsToggleGroup = new ToggleGroup();
        imageView = new ImageView();
        feedbackLabel = new Label();
        scoreLabel = new Label("Score: 0");

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> handleSubmission());

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.getChildren().addAll(questionLabel, imageView, createOptions(), submitButton, feedbackLabel, scoreLabel);

        // Apply CSS styles
        layout.setStyle("-fx-background-color: #f0f0f0;"); // Set background color
        questionLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;"); // Style for question label
        feedbackLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: red;"); // Style for feedback label
        scoreLabel.setStyle("-fx-font-size: 14px;"); // Style for score label

        displayQuestion(currentQuestionIndex);

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Trivia Game");
        primaryStage.show();
    }

    private VBox createOptions() {
        VBox optionsBox = new VBox(5);
        for (String option : questions[currentQuestionIndex].options) {
            RadioButton radioButton = new RadioButton(option);
            radioButton.setToggleGroup(optionsToggleGroup);
            optionsBox.getChildren().add(radioButton);
            radioButton.setStyle("-fx-font-size: 14px;");
        }
        return optionsBox;
    }

    private void displayQuestion(int index) {
        Question currentQuestion = questions[index];
        questionLabel.setText(currentQuestion.question);
        imageView.setImage(new Image(currentQuestion.imagePath));
        imageView.setFitWidth(200); // Set image width
        imageView.setFitHeight(200); // Set image height
        feedbackLabel.setText("");
        optionsToggleGroup.selectToggle(null);
    }

    private void displayResult(String resultMessage) {
        feedbackLabel.setText(resultMessage);
        if (currentQuestionIndex < questions.length) {
            // Display next question
            displayQuestion(currentQuestionIndex);
        } else {
            // Game over
            feedbackLabel.setText("Game over! Your final score is: " + score);
        }
    }

    private void handleSubmission() {
        RadioButton selectedRadioButton = (RadioButton) optionsToggleGroup.getSelectedToggle();
        if (selectedRadioButton != null) {
            int selectedAnswerIndex = optionsToggleGroup.getToggles().indexOf(selectedRadioButton);
            if (selectedAnswerIndex == questions[currentQuestionIndex].correctAnswerIndex) {
                score++;
                displayResult("Correct!");
            } else {
                displayResult("Incorrect. The correct answer is: " + questions[currentQuestionIndex].options[questions[currentQuestionIndex].correctAnswerIndex]);
            }
            scoreLabel.setText("Score: " + score);
            currentQuestionIndex++;
        } else {
            feedbackLabel.setText("Please select an option.");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class Question {
    String question;
    String[] options;
    int correctAnswerIndex;
    String imagePath;

    public Question(String question, String[] options, int correctAnswerIndex, String imagePath) {
        this.question = question;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
        this.imagePath = imagePath;
    }
}
